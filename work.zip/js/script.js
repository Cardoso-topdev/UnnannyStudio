/**
 * This is script for index page
 */

(function ($) {
  $(document).ready(function () {
    
  });
})(jQuery);
